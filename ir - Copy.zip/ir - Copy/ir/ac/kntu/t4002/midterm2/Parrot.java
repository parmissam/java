package ir.ac.kntu.t4002.midterm2;

public class Parrot extends Animal{

    public Parrot(String name, Main.State state) {
        super(name, state);
    }

    @Override
    public void eat() {

    }

    @Override
    public void sleep() {

    }

    @Override
    public AbstractState getState() {
        return null;
    }

    @Override
    public String getName() {
        return null;
    }
}
