package ir.ac.kntu.t4002.midterm2;

public class PanickyState extends AbstractState{

    public PanickyState(boolean foodNearBy, Main.State state) {
        super(foodNearBy,state);
    }

    public void run() {
        System.out.println("Run! Run! Run! with my highest possible speed!");
        setState(Main.State.NORMAL);
    }

    public void sleep() {
        System.out.println("Are you kidding me?!");
    }

    public void eat() {
        System.out.println("How the hell I can eat anything now! I must escape before being eaten by that fox!");
    }

}
