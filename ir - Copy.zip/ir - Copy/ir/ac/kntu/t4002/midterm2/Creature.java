package ir.ac.kntu.t4002.midterm2;

public interface Creature {
    void eat();

    void sleep();

    AbstractState getState();

    String getName();
}
