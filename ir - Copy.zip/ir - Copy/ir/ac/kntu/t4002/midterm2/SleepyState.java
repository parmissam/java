package ir.ac.kntu.t4002.midterm2;

public class SleepyState extends AbstractState{

    public SleepyState(boolean foodNearBy, Main.State state) {
        super(foodNearBy,state);
    }

    public void run() {
        System.out.println("Time for sleep! I do not want to run now!");
        setState(Main.State.NORMAL);
    }

    public void sleep() {
        System.out.println("Yeap. That's completely what I need now!");
        setState(Main.State.NORMAL);
    }

    public void eat() {
        System.out.println("I can try it, but do not promise to finish before falling asleep!");
    }
}
