package ir.ac.kntu.t4002.midterm2;

public class Person implements Creature{

    private String name;

    private Main.State state =Main.State.NORMAL;

    private AbstractState abstractState;

    public Person(String name,Main.State state) {
        this.name = name;
        this.state = state;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setState(Main.State state) {
        this.state = state;
    }

    public AbstractState getAbstractState() {
        return abstractState;
    }

    public void setAbstractState(AbstractState abstractState) {
        this.abstractState = abstractState;
    }

    @Override
    public void eat() {
        abstractState.eat();
    }

    @Override
    public void sleep() {
        abstractState.sleep();
    }

    @Override
    public AbstractState getState() {
        return getAbstractState();
    }

    @Override
    public String getName() {
        return getName();
    }
}
