package ir.ac.kntu.t4002.midterm2;

public abstract class AbstractState {

    private boolean foodNearBy;

    private Main.State state;

    public AbstractState(boolean foodNearBy, Main.State state) {
        this.foodNearBy=foodNearBy;
        this.state=state;
    }

    public void run(){
        System.out.println("Running");
    }

    public void sleep(){
        System.out.println("Sleeping");
    }

    public void eat(){
        System.out.println("Eating");
    }

    public boolean isFoodNearBy() {
        return foodNearBy;
    }

    public void setState(Main.State state) {
        this.state = state;
    }

    public Main.State getState() {
        return state;
    }
}
