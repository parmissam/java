package ir.ac.kntu.t4002.midterm2;

public class Animal implements Creature{

    private String name;

    private Main.State state = Main.State.NORMAL;

    private AbstractState abstractState;

    public Animal(String name, Main.State state) {
        this.name = name;
        this.state = state;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setState(Main.State state) {
        this.state = state;
    }

    public AbstractState getAbstractState() {
        return abstractState;
    }

    public void setAbstractState(AbstractState abstractState) {
        this.abstractState = abstractState;
    }

    @Override
    public void eat() {
        abstractState.eat();
    }

    @Override
    public void sleep() {
        abstractState.sleep();
    }

    @Override
    public AbstractState getState() {
        return getAbstractState();
    }

    @Override
    public String getName() {
        return getName();
    }

    private boolean foodNearBy() {
        // The method checks for food near by the rabbit. Exact implementation is not important
        return false;
    }

    @Override
    public String toString() {
        return "Animal{" +
                "name='" + name + '\'' +
                ", state=" + state +
                ", abstractState=" + abstractState +
                '}';
    }
}
