package ir.ac.kntu.t4002.midterm2;

import java.util.ArrayList;
import java.util.Random;

public class Main{

    public enum State { NORMAL, HUNGRY, PANICKY, SLEEPY }

    private ArrayList<Animal> animals=new ArrayList<>();

    private ArrayList<Main.State> states=new ArrayList<>();

    public void main(){
        states.add(State.HUNGRY);
        states.add(State.SLEEPY);
        states.add(State.NORMAL);
        states.add(State.PANICKY);
        Random random=new Random();
        animals.add(new Cat("a",states.get(random.nextInt(4))));
        animals.add(new Parrot("b",states.get(random.nextInt(4))));
        animals.add(new Lizard("c",states.get(random.nextInt(4))));
        for(int i=0;i<4;i++){
            for (int j=0;j<animals.size();j++){
                if(animals.get(j).getState().equals(states.get(i))){
                    System.out.println(animals.get(j));
                }
            }
        }
    }
}
