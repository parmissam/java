package ir.ac.kntu.t4002.midterm2;

public class Cat extends Animal{

    public Cat(String name, Main.State state) {
        super(name, state);
    }

    @Override
    public void eat() {
        getAbstractState().eat();
    }

    @Override
    public void sleep() {
        getAbstractState().sleep();
    }

    @Override
    public AbstractState getState() {
        return getAbstractState();
    }

    @Override
    public String getName() {
        return getName();
    }
}
