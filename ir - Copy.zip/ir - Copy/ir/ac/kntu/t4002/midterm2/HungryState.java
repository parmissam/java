package ir.ac.kntu.t4002.midterm2;

public class HungryState extends AbstractState{

    public HungryState(boolean foodNearBy, Main.State state) {
        super(foodNearBy,state);
    }

    public void run() {
        if (isFoodNearBy()) {
            System.out.println("Food is here and I am enjoying it. Why to run?");
            setState(Main.State.NORMAL);
        } else {
            System.out.println("Run for food with a low speed. I do not want to waste my remaining energy!");
        }
    }

    public void sleep() {
        System.out.println("I cannot fall asleep when I'm hungry!");
    }

    public void eat() {
        System.out.println("I could not wait for eating any more! Thank you!");
        setState(Main.State.NORMAL);
    }
}
