package ir.ac.kntu.t4002.midterm2;

public class NormalState extends AbstractState {

    public NormalState(boolean foodNearBy, Main.State state) {
        super(foodNearBy,state);
    }

    public void run() {
        System.out.println("No hurry at all! I prefer to walk instead!");
    }

    public void sleep() {
        System.out.println("Not sure to be able to sleep now! But I'll do my best!");
        if (Math.random() < .2) {
            setState(Main.State.SLEEPY);
        }
    }

    public void eat() {
        System.out.println("If you have something realy delicious, why not?");
    }
}
